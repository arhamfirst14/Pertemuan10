package sesi2_GUI;

public class Main {

    public static void main(String[] args) {
        Form_mhs form = new Form_mhs();
        new Form_mhs().setVisible(true);
    }
    
}
