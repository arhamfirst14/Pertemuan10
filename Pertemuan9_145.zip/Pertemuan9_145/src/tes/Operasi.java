package tes;

public interface Operasi {
    public void Bilangan();
    public void Prima();
    public void Pangkat();
    public void Akar();
}
