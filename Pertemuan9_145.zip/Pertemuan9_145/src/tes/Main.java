package tes;

import java.util.Scanner;

public class Main {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        Bilangan bil = new Bilangan();
        
        System.out.println("Masukkan bilangan pertama = ");
        double bil1=sc.nextDouble();
        
        bil = new Bilangan(bil1);
        bil.Akar();
        
    }
}
