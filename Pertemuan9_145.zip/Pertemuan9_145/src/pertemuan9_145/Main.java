package pertemuan9_145;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Kalkulator kal = new Kalkulator();
        
        System.out.println("Masukkan bilangan pertama = ");
        double bil1=sc.nextDouble();
        System.out.println("Masukkan bilangan kedua   = ");
        double bil2=sc.nextDouble();
        
        kal = new Kalkulator(bil1, bil2);
        System.out.println("\n HASIL PENJUMLAHAN");
        kal.Penjumlahan();
        System.out.println("\n HASIL PENGURANGAN");
        kal.Pengurangan();
        System.out.println("\n HASIL PERKALIAN");
        kal.Perkalian();
        System.out.println("\n HASIL PEMBAGIAN");
        kal.Pembagian();
    }
    
}
