
package pertemuan9_145;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class koneksiDB {
    public static Connection koneksi;
    
    public Connection getKoneksi(){
   if (koneksi == null){
       try {
           String url = "jdbc:mysql://localhost:3306/mahasiswa";
           String username = "root";
           String password = "";
           
           DriverManager.registerDriver(new com.mysql.jdbc.Driver());
           koneksi = DriverManager.getConnection(url, username, password);
           System.out.println("koneksi berhasil");
       }catch(SQLException e) {
           System.out.println("koneksi gagal !!" +e.getMessage());
       }
   }
        return koneksi;
    }

}
